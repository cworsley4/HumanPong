﻿using System;
using System.Collections;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Kinect;

namespace MyKinectGame
{
    class Ball
    {
        Vector2 location;
        Texture2D texture;
        Vector2 trajectory;
        Rectangle boundingBox;
        float velocity;
        SpriteFont font;
        int score1;
        int score2;
        SoundEffect wallHit;
        SoundEffect paddleHit;

        public Ball(Vector2 local, Texture2D tex, SpriteBatch spriteBatch, SpriteFont font, ArrayList sound)
        {
            location = local;
            texture = tex;
            trajectory = new Vector2(1f, 1f);
            boundingBox.X = (int)location.X;
            boundingBox.Y = (int)location.Y;
            velocity = 1f;
            this.font = font;
            score1 = 0;
            score2 = 0;
            wallHit = (SoundEffect)sound[1];
            paddleHit = (SoundEffect)sound[0];

        }

        public void Update(GameTime gametime, GraphicsDeviceManager gm, Item Paddle1, Item Paddle2)
        {
            //Place the bounding box at the same location as the ball sprite
            boundingBox.X = (int)location.X;
            boundingBox.Y = (int)location.Y;

            //hits floor
            if (location.Y + texture.Width >= gm.PreferredBackBufferHeight) 
            {
                trajectory.Y = -(velocity);
                velocity += .1f;
                wallHit.Play();
            }

            //hits ceiling
            if (location.Y <= 0)
            {
                trajectory.Y = velocity;
                velocity += .1f;
                wallHit.Play();
            }

            //hits right wall
            if ((location.X + texture.Width) >= gm.PreferredBackBufferWidth)
            {
                trajectory.X = -(velocity);
                velocity += .1f;
                score1++;
                wallHit.Play();
            }
            //hits left wall
            if(location.X <= 0)
            {
                trajectory.X = (velocity);
                velocity += .1f;
                score2++;
                wallHit.Play();
            }

            //Ask if the Rectangles of the ball and of paddle one have intersected.
            if(boundingBox.Intersects(Paddle2.getRectangle()))
            {
                trajectory.X = 5f;
                paddleHit.Play();
            }

            //Ask if the Rectangles of the ball and of paddle one have intersected.
            if (boundingBox.Intersects(Paddle1.getRectangle()))
            {
                trajectory.X = -5f;
                paddleHit.Play();
            }

            //Make the ball move.
            location += trajectory;
        }

        public void Draw(SpriteBatch spriteBatch)
        {
            //Update the score of the players
            spriteBatch.DrawString(font, "Player 1 score: " + score1, new Vector2(0f, 0f), Color.Red);
            spriteBatch.DrawString(font, "Player 2 score: " + score2, new Vector2(GraphicsDeviceManager.DefaultBackBufferWidth - 200, 0f), Color.Red);
            spriteBatch.Draw(texture, location, Color.White);
        }
    }
}
