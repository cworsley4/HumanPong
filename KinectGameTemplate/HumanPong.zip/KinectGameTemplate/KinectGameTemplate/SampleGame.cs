﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Kinect;

using KinectExplorer;

namespace MyKinectGame
{
    /*
     * You may want to take a Look at the methods in KinectManager and KinectGame
     * to access some helper methods.
     */
    public class SampleGame : KinectGame
    {
        Vector2 p1RhandPos;
        Vector2 p2LhandPos;
        Texture2D paddletex;
        Texture2D paddletex2;
        Texture2D balltex;
        SpriteBatch spriteBatch;
        SpriteFont font;
        Item paddle1;
        Item paddle2;
        Ball ball;
        SoundEffect hitsound;
        SoundEffect wallsound;
        ArrayList sounds = new ArrayList();

        //Most Kinect functionality is handled through
        //superclass methods, but if you need to access
        //the Kinect, do so with KinectManager.Kinect
        KinectSensor kinect = KinectManager.Kinect;

        public SampleGame(GameParameters gParams)
            : base(gParams) { } //Leave this blank!

        public override GameConfig GetConfig()
        {
            return new GameConfig("Human Pong", "Cecil Worsley and Christopher Bosack", "This is the Kinect adaptation of the classic Pong by Atari.");
        }

        public override void Initialize()
        {
            //Add sounds to ArrayList
            sounds.Add(hitsound);
            sounds.Add(wallsound);
            //Create ball
            ball = new Ball(new Vector2(400f, 0f), balltex, spriteBatch, font, sounds);
        }

        public override void LoadContent(ContentLoader content)
        {
            //Load content here
            paddletex = content.Load<Texture2D>("paddle1");
            paddletex2 = content.Load<Texture2D>("paddle2");
            balltex = content.Load<Texture2D>("ball");
            font = content.Load<SpriteFont>("basic");
            hitsound = content.Load<SoundEffect>("hitblip");
            wallsound = content.Load<SoundEffect>("wallblip");
        }

        public override void UnloadContent()
        {
            //Unload resources here
        }

        public override void Update(GameTime gameTime)
        {
            paddle1 = new Item(new Vector2(0f, 0f), paddletex, spriteBatch, gameTime);
            paddle2 = new Item(new Vector2(0f, 0f), paddletex2, spriteBatch, gameTime);
            spriteBatch = new SpriteBatch(GraphicsDevice);
            
            //Do update logic here
            //Send right hand position of Player1 to the Item update method
            if (SkeletonA != null)
            {
                p1RhandPos = GetJointPosOnScreen(SkeletonA.Joints[JointType.HandRight]);
                paddle1.Update(p1RhandPos.X, p1RhandPos.Y);
            }

            //Send right hand position of Player2 to the Item update method
            if (SkeletonB != null)
            {
                p2LhandPos = GetJointPosOnScreen(SkeletonB.Joints[JointType.HandLeft]);
                paddle2.Update(p2LhandPos.X, p2LhandPos.Y);
            }

            //Send positions of the paddles to the ball object
            ball.Update(gameTime, graphics, paddle1, paddle2);
        }

        public override void Draw(GameTime gameTime)
        {
            //Do draw logic here
            spriteBatch.Begin();

            DrawCamera();
            //DebugSkeletons();
            paddle1.Draw(spriteBatch);
            paddle2.Draw(spriteBatch);
            ball.Draw(spriteBatch);

            spriteBatch.End();
        }
    }
}
